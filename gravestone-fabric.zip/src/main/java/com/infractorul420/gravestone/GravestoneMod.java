package com.infractorul420.gravestone;

import net.fabricmc.api.ModInitializer;
import net.minecraft.block.Block;
import net.minecraft.util.Identifier;
import net.minecraft.util.registry.Registry;
import net.minecraft.block.entity.BlockEntityType;

public class GravestoneMod implements ModInitializer {
    public static final Block GRAVESTONE_BLOCK = new GravestoneBlock();
    public static BlockEntityType<GravestoneBlockEntity> GRAVESTONE_BLOCK_ENTITY;

    @Override
    public void onInitialize() {
        Registry.register(Registry.BLOCK, new Identifier("gravestone", "gravestone"), GRAVESTONE_BLOCK);
        GRAVESTONE_BLOCK_ENTITY = Registry.register(
            Registry.BLOCK_ENTITY_TYPE,
            new Identifier("gravestone", "gravestone_entity"),
            BlockEntityType.Builder.create(GravestoneBlockEntity::new, GRAVESTONE_BLOCK).build(null)
        );
    }
}