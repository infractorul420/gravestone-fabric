package com.infractorul420.gravestone;

import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.inventory.Inventories;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.util.math.BlockPos;

public class GravestoneBlockEntity extends BlockEntity {
    private final DefaultedList<ItemStack> inventory = DefaultedList.ofSize(36, ItemStack.EMPTY);

    public GravestoneBlockEntity(BlockPos pos, BlockState state) {
        super(GravestoneMod.GRAVESTONE_BLOCK_ENTITY, pos, state);
    }

    public void setItems(DefaultedList<ItemStack> items) {
        for (int i = 0; i < items.size(); i++) {
            this.inventory.set(i, items.get(i));
        }
    }

    @Override
    public void writeNbt(NbtCompound tag) {
        super.writeNbt(tag);
        Inventories.writeNbt(tag, inventory);
    }

    @Override
    public void readNbt(NbtCompound tag) {
        super.readNbt(tag);
        Inventories.readNbt(tag, inventory);
    }

    public DefaultedList<ItemStack> getItems() {
        return inventory;
    }
}