package com.infractorul420.gravestone;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Material;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityProvider;
import net.minecraft.util.math.BlockPos;

public class GravestoneBlock extends Block implements BlockEntityProvider {
    public GravestoneBlock() {
        super(Settings.of(Material.STONE).strength(1.5f));
    }

    @Override
    public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
        return new GravestoneBlockEntity(pos, state);
    }

    @Override
    public boolean hasBlockEntity(BlockState state) {
        return true;
    }
}